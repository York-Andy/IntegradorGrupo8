/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Administrador;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Lenovo
 */
public class AdministradorJpaController implements Serializable {
    
    private EntityManagerFactory emf;
   public AdministradorJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public AdministradorJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    }
    public void crearAdministrador(Administrador administrador) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(administrador);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el administrador", ex);
        } finally {
            em.close();
        }
    }

    public void cambiarAdministrador(Administrador administrador) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(administrador);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al editar el administrador", ex);
        } finally {
            em.close();
        }
    }

    public void eliminaradministrador(Long id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Administrador administrador = em.find(Administrador.class, id);
            em.remove(administrador);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el administrador", ex);
        } finally {
            em.close();
        }
    }

    public List<Administrador> ListaAdministradores() {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<Administrador> q = em.createQuery("SELECT a FROM Administrador a", Administrador.class);
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Administrador TraerAdministradorXid(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Administrador.class, id);
        } finally {
            em.close();
        }
    }

    public int getAdministradorCount() {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<Long> q = em.createQuery("SELECT COUNT(a) FROM Administrador a", Long.class);
            return q.getSingleResult().intValue();
        } finally {
            em.close();
        }
    }

    
}
