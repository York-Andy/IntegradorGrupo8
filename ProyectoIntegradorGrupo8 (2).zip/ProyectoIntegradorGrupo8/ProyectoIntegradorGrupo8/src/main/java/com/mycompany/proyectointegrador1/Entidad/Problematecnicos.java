/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.Entidad;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Data;
@Entity
@Data
public class Problematecnicos {
  @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long IdTecnicoProblema;

    @ManyToOne
    @JoinColumn(name = "IdTecnico")
    private Tecnico tecnico;

    @ManyToOne
    @JoinColumn(name = "IdProblema")
    private Problema problema;

    public Problematecnicos() {
    }

    public Problematecnicos(Long IdTecnicoProblema, Tecnico tecnico, Problema problema) {
        this.IdTecnicoProblema = IdTecnicoProblema;
        this.tecnico = tecnico;
        this.problema = problema;
    }

    public Problematecnicos(Tecnico tecnico, Problema problema) {
        this.tecnico = tecnico;
        this.problema = problema;
    }
    
   
}
