/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.ColchonHorasEstimadas;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class ColchonHorasEstimadasJpaController {
   private EntityManagerFactory emf;
   public ColchonHorasEstimadasJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public ColchonHorasEstimadasJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    }
    public void crearColchon(ColchonHorasEstimadas colchon) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(colchon);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el colchón de horas estimadas", ex);
        } finally {
            em.close();
        }
    }

    public ColchonHorasEstimadas findColchon(Integer id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(ColchonHorasEstimadas.class, id);
        } finally {
            em.close();
        }
    }

    public List<ColchonHorasEstimadas> ListarAllColchones() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT HorasEstimadas FROM ColchonHorasEstimadas c", ColchonHorasEstimadas.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void cambiarColchonH(ColchonHorasEstimadas colchon) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(colchon);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar el colchón de horas estimadas", ex);
        } finally {
            em.close();
        }
    }

    public void BorrarColchonH(Integer id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            ColchonHorasEstimadas colchon = em.find(ColchonHorasEstimadas.class, id);
            em.remove(colchon);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el colchón de horas estimadas", ex);
        } finally {
            em.close();
        }
    }
  
}
