/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectointegrador1;

import com.mycompany.proyectointegrador1.AccesoAdatos.ClienteJpaController;
import com.mycompany.proyectointegrador1.AccesoAdatos.Controladorapersistencia;
import com.mycompany.proyectointegrador1.Entidad.Cliente;
import java.util.List;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class ProyectoIntegrador1 {

    public static void main(String[] args) {
       Controladorapersistencia controladora = new Controladorapersistencia(); 
      // Crea la fábrica de EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");

        // Prueba de ClienteJpaController
        ClienteJpaController clienteController = new ClienteJpaController(emf);
        Cliente cliente = new Cliente();  // Asegúrate de inicializar tu entidad con datos adecuados
        clienteController.creaRCliente(cliente);
        // Crear un nuevo cliente
        Cliente nuevoCliente = new Cliente("leo matioli", 123456789, true);
        // Configura los datos del nuevo cliente
        // ...

        clienteController.creaRCliente(nuevoCliente);
        System.out.println("Cliente creado con ID: " + nuevoCliente.toString());

        // Obtener un cliente por su ID
        Integer clienteId = 1; // Cambia esto con un ID existente en tu base de datos
        Cliente clienteEncontrado = clienteController.findCliente(2);
        System.out.println("Cliente encontrado: " + clienteEncontrado);

        // Listar todos los clientes
        List<Cliente> listaClientes = clienteController.ListarAllClientes();
        System.out.println("Lista de clientes:");
        for (Cliente c : listaClientes) {
            System.out.println(c);
      

        // Actualizar un cliente
        Cliente clienteParaActualizar =new Cliente("Sonia Sanchez",6677766,true);// Obtén un cliente existente o utiliza el que acabas de crear
        // Configura los nuevos datos del cliente
        // ...

        clienteController.CambiarCliente(clienteParaActualizar);
        System.out.println("Cliente actualizado: " + clienteParaActualizar);

        // Eliminar un cliente
        Integer clienteIdAEliminar = 2;// Cambia esto con un ID existente en tu base de datos
        clienteController.Borrarcliente(11);
        System.out.println("Cliente eliminado con ID: " + clienteIdAEliminar);

        // Cierra la fábrica de EntityManager cuando hayas terminado
        emf.close();
    
    }

   
    
}

}