/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Siniestro;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class SiniestroJpaController {
   private EntityManagerFactory emf;
   public SiniestroJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public SiniestroJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    }
    public void crearSiniestro(Siniestro siniestro) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(siniestro);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el siniestro", ex);
        } finally {
            em.close();
        }
    }

    public Siniestro findSiniestro(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Siniestro.class, id);
        } finally {
            em.close();
        }
    }

    public List<Siniestro> listarAllSiniestros() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT * FROM Siniestro s", Siniestro.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void Cambiarsiniestro(Siniestro siniestro) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(siniestro);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar el siniestro", ex);
        } finally {
            em.close();
        }
    }

    public void BorrarSiniestro(Long id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Siniestro siniestro = em.find(Siniestro.class, id);
            em.remove(siniestro);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el siniestro", ex);
        } finally {
            em.close();
        }
    }

}
