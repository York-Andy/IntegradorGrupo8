/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

/**
 *
 * @author Lenovo
 */
public class Controladorapersistencia {
  AdministradorJpaController adminJpa =new AdministradorJpaController();
  ClienteJpaController cliJpa =new ClienteJpaController();
  AsignacionSiniestroJpaController asJc =new AsignacionSiniestroJpaController();
  ColchonHorasEstimadasJpaController chejc= new ColchonHorasEstimadasJpaController();
  NotificacionJpaController njc = new NotificacionJpaController();
  ProblemaJpaController pjc = new ProblemaJpaController();
  ServiciosJpaController sjc =new ServiciosJpaController();
  SiniestroJpaController sinijc = new SiniestroJpaController();
  TecnicoJpaController tjc = new TecnicoJpaController();
  ContratoJpaController cjc=new ContratoJpaController();
}
