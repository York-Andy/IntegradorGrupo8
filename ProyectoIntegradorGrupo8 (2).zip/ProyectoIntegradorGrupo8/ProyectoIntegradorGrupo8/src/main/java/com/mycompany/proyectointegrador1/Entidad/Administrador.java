/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.Entidad;
import com.mycompany.proyectointegrador1.Entidad.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import lombok.Data;
@Data
@Entity
public class Administrador implements Serializable {
     @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @OneToMany(mappedBy = "administrador")
    private List<AsignacionSiniestro> asignacionesSiniestros;
     @OneToMany (mappedBy ="administrador")
    private List< Notificacion> notificacion;

    public Administrador() {
        this.asignacionesSiniestros = new ArrayList<>();
    } 
    public void asignarSiniestro(Tecnico tecnico, Cliente cliente) {
        Siniestro siniestro = new Siniestro( cliente); // Crear un nuevo siniestro solo con el cliente
        siniestro.getClass().toString(); // Asignamos el técnico al siniestro

        tecnico.agregarSiniestro(siniestro);
        cliente.agregarSiniestro(siniestro);
      

        notificarTecnico(tecnico, siniestro);
        notificarCliente(cliente, tecnico);
    }

    private void notificarTecnico(Tecnico tecnico, Siniestro siniestro) {
        // Lógica para notificar al técnico (puede ser por consola, correo electrónico, etc.)
        System.out.println("Se ha asignado un nuevo siniestro a " + tecnico.getClass().getName());
        System.out.println("Detalles del siniestro: " + siniestro);
    }

    private void notificarCliente(Cliente cliente, Tecnico tecnico) {
        // Lógica para notificar al cliente (puede ser por consola, correo electrónico, etc.)
        System.out.println("Hemos asignado un técnico, " + tecnico.getClass().getName() + ", para atender su siniestro.");
        System.out.println("Detalles del técnico asignado: " + tecnico);
    }

    // Otros métodos y atributos necesarios

}
