/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.Entidad;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.sql.Date;
import java.util.List;
import javax.persistence.JoinColumn;
import lombok.Data;

@Entity
@Data
public class Siniestro {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer IdSiniestro;
  private String Descripcion;
  private Date FechaDeSiniestro; 
  private Date FechaDeResoluccion;
  private Boolean estado;
  @ManyToOne //relacion con servicios
  private Servicios servicios;
  @OneToMany //relacion con tecnico
  private Tecnico tecnico;
  @OneToMany(mappedBy ="problema")
  private List<Problema> problemas;
   @ManyToOne
    @JoinColumn(name="id_cliente")
  private Cliente cliente;

    public Siniestro(Cliente cliente) {
    }

    public Siniestro(Integer IdSiniestro, String Descripcion, Date FechaDeSiniestro, Date FechaDeResoluccion, Boolean estado, Servicios servicios, Tecnico tecnico, List<Problema> problemas, Cliente cliente) {
        this.IdSiniestro = IdSiniestro;
        this.Descripcion = Descripcion;
        this.FechaDeSiniestro = FechaDeSiniestro;
        this.FechaDeResoluccion = FechaDeResoluccion;
        this.estado = estado;
        this.servicios = servicios;
        this.tecnico = tecnico;
        this.problemas = problemas;
        this.cliente = cliente;
    }

    public Siniestro(String Descripcion, Date FechaDeSiniestro, Date FechaDeResoluccion, Boolean estado, Servicios servicios, Tecnico tecnico, List<Problema> problemas, Cliente cliente) {
        this.Descripcion = Descripcion;
        this.FechaDeSiniestro = FechaDeSiniestro;
        this.FechaDeResoluccion = FechaDeResoluccion;
        this.estado = estado;
        this.servicios = servicios;
        this.tecnico = tecnico;
        this.problemas = problemas;
        this.cliente = cliente;
    }

    

    
  
  
}
