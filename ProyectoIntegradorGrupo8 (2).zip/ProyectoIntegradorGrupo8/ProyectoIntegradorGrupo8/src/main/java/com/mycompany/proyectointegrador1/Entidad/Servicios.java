/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.Entidad;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.List;
import lombok.Data;

@Entity
@Data
public class Servicios {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Integer IdServicio;
   private String descripcion;
   @ManyToOne //relacion con cliente
   private Cliente cliente ;
   @OneToMany(mappedBy ="servicio")
   private List<Siniestro>siniestro;

    public Servicios() {
    }

    public Servicios(Integer IdServicio, String descripcion, Cliente cliente, List<Siniestro> siniestro) {
        this.IdServicio = IdServicio;
        this.descripcion = descripcion;
        this.cliente = cliente;
        this.siniestro = siniestro;
    }
   
}
