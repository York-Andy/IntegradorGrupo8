/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.Entidad;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import lombok.Data;

@Entity
@Data
public class Notificacion {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
   private Integer IdNotificacion;
  private String medioPreferido;

    @ManyToOne
    @JoinColumn(name ="IdTecnico") // relacion con tecnico
    private Tecnico tecnico;

    @ManyToOne
    @JoinColumn(name="IdCliente") // relacion con cliente
    private Cliente cliente;

    public Notificacion() {
    }
   
}
