/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.AsignacionSiniestro;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author Lenovo
 */
public class AsignacionSiniestroJpaController {
     private EntityManagerFactory emf;
   public AsignacionSiniestroJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public AsignacionSiniestroJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    }
public void crearAsignacionsiniestro(AsignacionSiniestro asignacionSiniestro) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(asignacionSiniestro);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear la asignación de siniestro", ex);
        } finally {
            em.close();
        }
    }

    public void cambiarasignacionsiniestro(AsignacionSiniestro asignacionSiniestro) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(asignacionSiniestro);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al editar la asignación de siniestro", ex);
        } finally {
            em.close();
        }
    }

    public void eliminarasignacionSiniestro(Long id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            AsignacionSiniestro asignacionSiniestro = em.find(AsignacionSiniestro.class, id);
            em.remove(asignacionSiniestro);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar la asignación de siniestro", ex);
        } finally {
            em.close();
        }
    }

    public List<AsignacionSiniestro> ListarAsignacionSiniestros() {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<AsignacionSiniestro> q = em.createQuery("SELECT a FROM AsignacionSiniestro a", AsignacionSiniestro.class);
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public AsignacionSiniestro TraerXIDAsignacionSiniestro(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(AsignacionSiniestro.class, id);
        } finally {
            em.close();
        }
    }

    public int getAsignacionSiniestroCount() {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<Long> q = em.createQuery("SELECT COUNT(a) FROM AsignacionSiniestro a", Long.class);
            return q.getSingleResult().intValue();
        } finally {
            em.close();
        }
    }
}
