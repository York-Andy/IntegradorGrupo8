/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Problematecnicos;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;

/**
 *
 * @author Lenovo
 */
public class ProblematecnicosJpaController {

    private EntityManagerFactory emf;
   public ProblematecnicosJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public ProblematecnicosJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    }  
    public void create(Problematecnicos problemasTecnicos) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(problemasTecnicos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Problematecnicos problemasTecnicos) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(problemasTecnicos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Problematecnicos problemaTecnicos;
            try {
                problemaTecnicos = em.getReference(Problematecnicos.class, id);
                problemaTecnicos.getClass().getName(); // Esto lanza una excepción si no existe
            } catch (EntityNotFoundException enfe) {
                throw new RuntimeException("El problema técnico con id " + id + " no existe.", enfe);
            }
            em.remove(problemaTecnicos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Problematecnicos> findProblemasTecnicosEntities() {
        return findProblemasTecnicosEntities(true, -1, -1);
    }

    public List<Problematecnicos> findProblemasTecnicosEntities(int maxResults, int firstResult) {
        return findProblemasTecnicosEntities(false, maxResults, firstResult);
    }

    private List<Problematecnicos> findProblemasTecnicosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Problematecnicos.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
}
