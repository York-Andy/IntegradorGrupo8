/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.Entidad;

import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import lombok.Data;
@Data
@Entity
public class Contrato {
   @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String razonSocial;
    private String cuit;
    private Date fechaInicio;
    private Date fechaFin;

    @ManyToOne
    private Cliente cliente;

    @ManyToOne
    private Tecnico tecnico;
     @ManyToOne
    private Administrador administrador;

    public Contrato(Long id, String razonSocial, String cuit, Date fechaInicio, Date fechaFin, Cliente cliente, Tecnico tecnico, Administrador administrador) {
        this.id = id;
        this.razonSocial = razonSocial;
        this.cuit = cuit;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.cliente = cliente;
        this.tecnico = tecnico;
        this.administrador = administrador;
    }

   
    public Contrato() {
    }

    public Contrato(String razonSocial, String cuit, Date fechaInicio, Date fechaFin, Cliente cliente, Tecnico tecnico) {
        this.razonSocial = razonSocial;
        this.cuit = cuit;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.cliente = cliente;
        this.tecnico = tecnico;
    }
    
}
