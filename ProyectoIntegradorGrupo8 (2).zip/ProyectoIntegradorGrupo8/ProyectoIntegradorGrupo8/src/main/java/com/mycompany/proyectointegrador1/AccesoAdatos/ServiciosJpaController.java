/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Servicios;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class ServiciosJpaController {
  private EntityManagerFactory emf;
   public ServiciosJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public ServiciosJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    } 
    public void crearServicio(Servicios servicios) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(servicios);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el servicio", ex);
        } finally {
            em.close();
        }
    }

    public Servicios findServicios(Integer id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Servicios.class, id);
        } finally {
            em.close();
        }
    }

    public List<Servicios> listarAllServicios() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT * FROM Servicios s", Servicios.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void cambiarservicio(Servicios servicios) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(servicios);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar el servicio", ex);
        } finally {
            em.close();
        }
    }

    public void BorrarServicio(Integer id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Servicios servicios = em.find(Servicios.class, id);
            em.remove(servicios);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el servicio", ex);
        } finally {
            em.close();
        }
    }
}
