/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Contrato;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class ContratoJpaController {
   private EntityManagerFactory emf;
   public ContratoJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public ContratoJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    } 
     public void crearcontrato(Contrato contrato) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(contrato);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el contrato", ex);
        } finally {
            em.close();
        }
     }
      public Contrato findContrato(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Contrato.class, id);
        } finally {
            em.close();
        }
    }

    public List<Contrato> ListarAllContratos() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT * FROM Contrato c", Contrato.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void Cambiarcontrato(Contrato contrato) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(contrato);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar el contrato", ex);
        } finally {
            em.close();
        }
    }

    public void BorrarContrato(Long id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Contrato contrato = em.find(Contrato.class, id);
            em.remove(contrato);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el contrato", ex);
        } finally {
            em.close();
        }
    }
}
