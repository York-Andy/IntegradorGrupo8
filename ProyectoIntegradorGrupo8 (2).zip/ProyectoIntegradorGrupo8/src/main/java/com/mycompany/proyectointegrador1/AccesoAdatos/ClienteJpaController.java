/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Cliente;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class ClienteJpaController {
   private EntityManagerFactory emf;
   public ClienteJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public ClienteJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    }
    public void creaRCliente(Cliente cliente) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(cliente);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el cliente", ex);
        } finally {
            em.close();
        }
    }

    public Cliente findCliente(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }

    public List<Cliente> ListarAllClientes() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT * FROM Cliente c", Cliente.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void CambiarCliente(Cliente cliente) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(cliente);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar el cliente", ex);
        } finally {
            em.close();
        }
    }

    public void Borrarcliente(Long id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Cliente cliente = em.find(Cliente.class, id);
            em.remove(cliente);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el cliente", ex);
        } finally {
            em.close();
        }
    }
  
}
