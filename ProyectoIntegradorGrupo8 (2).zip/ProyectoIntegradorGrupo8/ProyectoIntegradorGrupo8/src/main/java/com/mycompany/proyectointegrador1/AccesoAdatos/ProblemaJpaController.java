/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Problema;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class ProblemaJpaController {
  private EntityManagerFactory emf;
   public ProblemaJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public ProblemaJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    }
    public void crearProblema(Problema problema) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(problema);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el problema", ex);
        } finally {
            em.close();
        }
    }

    public Problema findProblema(Integer id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Problema.class, id);
        } finally {
            em.close();
        }
    }

    public List<Problema> ListarAllProblemas() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT * FROM Problema p", Problema.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void Cambiarproblema(Problema problema) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(problema);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar el problema", ex);
        } finally {
            em.close();
        }
    }

    public void BorrarProblema(Integer id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Problema problema = em.find(Problema.class, id);
            em.remove(problema);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el problema", ex);
        } finally {
            em.close();
        }
    }
}
