/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Notificacion;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class NotificacionJpaController {
   private EntityManagerFactory emf;
   public NotificacionJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public NotificacionJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    } 
    public void crearNotificacion(Notificacion notificacion) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(notificacion);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear la notificación", ex);
        } finally {
            em.close();
        }
    }

    public Notificacion findNotificacion(Integer id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Notificacion.class, id);
        } finally {
            em.close();
        }
    }

    public List<Notificacion> listarAllNotificaciones() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT n FROM Notificacion n", Notificacion.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void cambiarContarato(Notificacion notificacion) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(notificacion);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar la notificación", ex);
        } finally {
            em.close();
        }
    }

    public void Borrarcontrato(Integer id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Notificacion notificacion = em.find(Notificacion.class, id);
            em.remove(notificacion);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar la notificación", ex);
        } finally {
            em.close();
        }
    }
}
