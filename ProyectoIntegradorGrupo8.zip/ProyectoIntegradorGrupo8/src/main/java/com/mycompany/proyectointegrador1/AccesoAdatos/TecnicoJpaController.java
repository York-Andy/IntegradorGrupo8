/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.AccesoAdatos;

import com.mycompany.proyectointegrador1.Entidad.Tecnico;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Lenovo
 */
public class TecnicoJpaController {
    private EntityManagerFactory emf;
   public TecnicoJpaController(EntityManagerFactory emf){
   this.emf =emf;
   }
    public TecnicoJpaController() {
        emf =Persistence.createEntityManagerFactory("persistenciaIntegradorPAPu");
    } 
        public void creartecnico(Tecnico tecnico) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(tecnico);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al crear el técnico", ex);
        } finally {
            em.close();
        }
    }

    public Tecnico findTecnico(Integer id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Tecnico.class, id);
        } finally {
            em.close();
        }
    }

    public List<Tecnico> ListarAllTecnicos() {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT * FROM Tecnico t", Tecnico.class).getResultList();
        } finally {
            em.close();
        }
    }

    public void CambiarTecnico(Tecnico tecnico) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.merge(tecnico);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al actualizar el técnico", ex);
        } finally {
            em.close();
        }
    }

    public void Borrartecnico(Integer id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            Tecnico tecnico = em.find(Tecnico.class, id);
            em.remove(tecnico);
            et.commit();
        } catch (Exception ex) {
            if (et != null && et.isActive()) {
                et.rollback();
            }
            throw new RuntimeException("Error al eliminar el técnico", ex);
        } finally {
            em.close();
        }
    }

}
