/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectointegrador1;

import com.mycompany.proyectointegrador1.AccesoAdatos.Controladorapersistencia;

/**
 *
 * @author Lenovo
 */
public class ProyectoIntegrador1 {

    public static void main(String[] args) {
       Controladorapersistencia controladora = new Controladorapersistencia(); 
      
    }
}
