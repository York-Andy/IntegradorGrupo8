/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectointegrador1.Entidad;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Data;

@Entity
@Data
public class ColchonHorasEstimadas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Integer IdSiniestros;
   private int IdHorasEstimadas;
   private int HorasEstimadas;
}
